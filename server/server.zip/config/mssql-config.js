module.exports = {
  // HOST: process.env.MSSQL_HOST,
  // USER: process.env.MSSQL_USER,
  // PASSWORD: process.env.MSSQL_PASSWORD,
  // DB: process.env.MSSQL_DATABASE,
  // HOST: '103.125.255.88',
  HOST: 'localhost',
  USER: 'ryansoftcom_ponditi_user',
  // USER: 'shayon',
  PASSWORD: 'Ponditi2022',
  // PASSWORD: 'Test1234',
  DB: 'ryansoftcom_ponditi_db',
  dialect: 'mysql',

  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000,
  },

  dialectOptions: {
    // Observe the need for this nested `options` field for MSSQL
    options: {
      // Your tedious options here
      useUTC: false,
      dateFirst: 1,
    },
  },
};
